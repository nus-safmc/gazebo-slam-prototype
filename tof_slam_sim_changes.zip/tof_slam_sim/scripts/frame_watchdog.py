#!/usr/bin/env python3
"""Wrapper to launch the frame_watchdog node."""

from tof_slam_sim.frame_watchdog import main

if __name__ == '__main__':
    main()
