#!/usr/bin/env python3
from __future__ import annotations
import os
import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.node import Node

class AutoPilot(Node):
    def __init__(self) -> None:
        super().__init__('auto_pilot')
        topic = os.environ.get('AP_TOPIC', '/cmd_vel')
        qos = int(os.environ.get('AP_QOS_DEPTH', '10'))
        self.pub = self.create_publisher(Twist, topic, qos)

        lin_x = float(os.environ.get('AP_LIN_X', '0.3'))
        lin_y = float(os.environ.get('AP_LIN_Y', '0.0'))
        ang_z = float(os.environ.get('AP_ANG_Z', '0.3'))

        self.msg = Twist()
        self.msg.linear.x = lin_x
        self.msg.linear.y = lin_y
        self.msg.linear.z = 0.0
        self.msg.angular.z = ang_z

        hz = float(os.environ.get('AP_RATE', '10.0'))
        self.timer = self.create_timer(1.0 / hz, self._tick)
        self.create_subscription(Odometry, '/odom', self._odom_cb, 10)
        self.get_logger().info(f'[/home/rex/gazebo-slam-prototype/.pixi/envs/jazzy/lib/python3.12/site-packages/tof_slam_sim/auto_pilot_node.py] Publishing Twist on {topic} @ {hz} Hz: lin=({lin_x},{lin_y},0.0) ang.z={ang_z}')

    def _tick(self) -> None:
        self.pub.publish(self.msg)

    def _odom_cb(self, msg: Odometry) -> None:
        # noop; keeping the subscription for future extensions
        pass

def main() -> None:
    rclpy.init()
    node = AutoPilot()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
