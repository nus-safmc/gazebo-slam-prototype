#!/usr/bin/env python3
"""Script entry point for the autopilot publisher."""

from tof_slam_sim.auto_pilot_node import main


if __name__ == '__main__':
    main()
