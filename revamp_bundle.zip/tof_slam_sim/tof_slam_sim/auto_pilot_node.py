#!/usr/bin/env python3
# Minimal, crash-proof autopilot: publish constant Twist at 10 Hz.
from __future__ import annotations
import os
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from geometry_msgs.msg import Twist

def _qos_cmd(depth: int = 10) -> QoSProfile:
    return QoSProfile(
        reliability=ReliabilityPolicy.RELIABLE,
        history=HistoryPolicy.KEEP_LAST,
        depth=depth,
        durability=DurabilityPolicy.VOLATILE,
    )

class AutoPilot(Node):
    def __init__(self) -> None:
        super().__init__('auto_pilot')
        topic = os.environ.get('AP_TOPIC', '/cmd_vel')
        hz = max(1.0, float(os.environ.get('AP_RATE', '10.0')))
        self.lin_x = float(os.environ.get('AP_LIN_X', '0.3'))
        self.lin_y = float(os.environ.get('AP_LIN_Y', '0.0'))
        self.ang_z = float(os.environ.get('AP_ANG_Z', '0.3'))

        self.pub = self.create_publisher(Twist, topic, _qos_cmd())
        self.timer = self.create_timer(1.0 / hz, self._tick)

        self.get_logger().debug(
            f"Publishing Twist on {topic} @ {hz:.1f} Hz: "
            f"lin=({self.lin_x},{self.lin_y},0.0) ang.z={self.ang_z}"
        )

    def _tick(self) -> None:
        msg = Twist()
        msg.linear.x = self.lin_x
        msg.linear.y = self.lin_y
        msg.linear.z = 0.0
        msg.angular.z = self.ang_z
        self.pub.publish(msg)

def main() -> None:
    rclpy.init()
    node = AutoPilot()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            node.pub.publish(Twist())  # stop on shutdown
        except Exception:
            pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
