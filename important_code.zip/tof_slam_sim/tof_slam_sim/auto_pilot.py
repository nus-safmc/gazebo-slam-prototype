"""Backward-compatible entry point for the autopilot."""

from .auto_pilot_node import main

__all__ = ['main']
