"""Provide a temporary map->odom transform until SLAM publishes one."""

from __future__ import annotations

from dataclasses import dataclass

import rclpy
from rclpy.duration import Duration
from rclpy.node import Node
from rclpy.time import Time
from tf2_ros import (
    Buffer,
    TransformBroadcaster,
    TransformListener,
    TransformException,
)
from geometry_msgs.msg import TransformStamped


class MapTFFallback(Node):
    """Broadcast an identity map->odom transform if none exists yet."""

    def __init__(self) -> None:
        super().__init__('map_tf_fallback')
        self.parent_frame = self.declare_parameter('parent_frame', 'map').value
        self.child_frame = self.declare_parameter('child_frame', 'odom').value
        self.publish_period = float(self.declare_parameter('publish_period', 0.5).value)
        self.timeout = Duration(seconds=float(self.declare_parameter('fallback_timeout', 120.0).value))
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self, spin_thread=True)
        self.broadcaster = TransformBroadcaster(self)

        self._fallback_active = False
        self._last_publish_time: Time | None = None
        self._started = self.get_clock().now()

        self.timer = self.create_timer(self.publish_period, self._tick)
        # Seed the TF tree immediately.
        self._publish_identity(self._started)
        self.get_logger().info(
            f'Waiting for transform {self.parent_frame} -> {self.child_frame}; '
            f'publishing fallback identity if absent.'
        )

    def _tick(self) -> None:
        now = self.get_clock().now()

        # Stop publishing after timeout to avoid masking persistent issues.
        if self._fallback_active and now - self._started > self.timeout:
            elapsed = (now - self._started).nanoseconds * 1e-9
            self.get_logger().warning(
                'Fallback transform still required after %.0f s; keeping it active '
                'but you should ensure SLAM publishes map->odom.' % elapsed
            )

        try:
            tf = self.tf_buffer.lookup_transform(
                self.parent_frame,
                self.child_frame,
                rclpy.time.Time())
        except TransformException:
            self._publish_identity(now)
            return

        msg_time = Time.from_msg(tf.header.stamp)
        if self._fallback_active:
            if self._last_publish_time is not None and msg_time > self._last_publish_time:
                # Another node took over.
                self._fallback_active = False
                self.get_logger().info(
                    f'Transform {self.parent_frame}->{self.child_frame} now provided ({msg_time.nanoseconds}); '
                    'stopping fallback.'
                )
                return
            else:
                # Still us; refresh identity.
                self._publish_identity(now)
        else:
            # Someone else already provides it; nothing to do.
            return

    def _publish_identity(self, stamp: Time) -> None:
        msg = TransformStamped()
        msg.header.stamp = stamp.to_msg()
        msg.header.frame_id = self.parent_frame
        msg.child_frame_id = self.child_frame
        msg.transform.rotation.w = 1.0
        self.broadcaster.sendTransform(msg)

        self._fallback_active = True
        self._last_publish_time = stamp
        self.get_logger().debug(
            f'Broadcasting fallback transform {self.parent_frame}->{self.child_frame} (identity).'
        )


def main() -> None:
    rclpy.init()
    node = MapTFFallback()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


__all__ = ['MapTFFallback', 'main']
