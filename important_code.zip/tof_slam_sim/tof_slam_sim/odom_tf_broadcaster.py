"""Broadcast TF from nav_msgs/Odometry messages."""

from __future__ import annotations

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster


class OdomTFBroadcaster(Node):
    """Convert /odom messages into TF odom -> base_link."""

    def __init__(self) -> None:
        super().__init__('odom_tf_broadcaster')
        # Do NOT declare 'use_sim_time' here; launch/YAML sets it.
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('default_child_frame', 'base_link')

        topic = self.get_parameter('odom_topic').get_parameter_value().string_value or '/odom'
        self._default_child = (
            self.get_parameter('default_child_frame').get_parameter_value().string_value or 'base_link'
        )

        self._broadcaster = TransformBroadcaster(self)
        self.create_subscription(Odometry, topic, self._callback, 10)
        self.get_logger().info(f'Broadcasting TF from odometry topic {topic}')

    def _callback(self, msg: Odometry) -> None:
        child = msg.child_frame_id or self._default_child
        if not child:
            return

        # If stamp is zero (can happen at sim bring-up), skip this message.
        if msg.header.stamp.sec == 0 and msg.header.stamp.nanosec == 0:
            return

        t = TransformStamped()
        # Use the odometry's timestamp so TF aligns with /clock.
        t.header.stamp = msg.header.stamp
        t.header.frame_id = msg.header.frame_id or 'odom'
        t.child_frame_id = child
        t.transform.translation.x = msg.pose.pose.position.x
        t.transform.translation.y = msg.pose.pose.position.y
        t.transform.translation.z = msg.pose.pose.position.z
        t.transform.rotation = msg.pose.pose.orientation
        self._broadcaster.sendTransform(t)


def main() -> None:
    rclpy.init()
    node = OdomTFBroadcaster()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


__all__ = ['OdomTFBroadcaster', 'main']
