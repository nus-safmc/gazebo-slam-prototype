#!/usr/bin/env python3
"""Wrapper to launch the map_tf_fallback node with python -m."""

from tof_slam_sim.map_tf_fallback import main

if __name__ == '__main__':
    main()
